dw-2020-parcial-1
================
Tepi
9/3/2020

# Examen parcial

Indicaciones generales:

  - Usted tiene el período de la clase para resolver el examen parcial.

  - La entrega del parcial, al igual que las tareas, es por medio de su
    cuenta de github, pegando el link en el portal de MiU.

  - Pueden hacer uso del material del curso e internet (stackoverflow,
    etc.). Sin embargo, si encontramos algún indicio de copia, se
    anulará el exámen para los estudiantes involucrados. Por lo tanto,
    aconsejamos no compartir las agregaciones que generen.

## Sección I: Preguntas teóricas.

  - Existen 10 preguntas directas en este Rmarkdown, de las cuales usted
    deberá responder 5. Las 5 a responder estarán determinadas por un
    muestreo aleatorio basado en su número de carné.

  - Ingrese su número de carné en `set.seed()` y corra el chunk de R
    para determinar cuáles preguntas debe responder.

<!-- end list -->

``` r
#set.seed("20180210") 
v<- 1:10
preguntas <-sort(sample(v, size = 5, replace = FALSE ))

paste0("Mis preguntas a resolver son: ",paste0(preguntas,collapse = ", "))
```

    ## [1] "Mis preguntas a resolver son: 3, 6, 7, 8, 10"

### Listado de preguntas teóricas

  - Las preguntas que me tocaron son 2,5,8,9,10 cuando le doy knit salen
    otras en el Markdown pero estas estan en el codigo. Las preguntas
    estan resueltas abajo de las indicadas

<!-- end list -->

1.  Para las siguientes sentencias de `base R`, liste su contraparte de
    `dplyr`:
      - `str()`
      - `df[,c("a","b")]`
      - `names(df)[4] <- "new_name"` donde la posición 4 corresponde a
        la variable `old_name`
      - `df[df$variable == "valor",]`
2.  Al momento de filtrar en SQL, ¿cuál keyword cumple las mismas
    funciones que el keyword `OR` para filtrar uno o más elementos una
    misma columna?

La Keyword que funciona igual que OR la cual nos permite filtrar dado un
condición o la otra es WHERE AND la cual permite al igual que el OR
filtrar dentro de multiples condiciones.

3.  ¿Por qué en R utilizamos funciones de la familia apply
    (lapply,vapply) en lugar de utilizar ciclos?

4.  ¿Cuál es la diferencia entre utilizar `==` y `=` en R?

5.  ¿Cuál es la forma correcta de cargar un archivo de texto donde el
    delimitador es `:`?

La forma correcta de cargar un archivo donde mi limitador sea : es con
esta formula read\_delim y dentro del parametro delim = colocamos “:” y
esto lo que le dice a la función es que el delimitador que se uso en la
data es : y a la hora de cargar el archivo este va tomar : como
delimitador

6.  ¿Qué es un vector y en qué se diferencia en una lista en R?

7.  ¿Qué pasa si quiero agregar una nueva categoría a un factor que no
    se encuentra en los niveles existentes?

8.  Si en un dataframe, a una variable de tipo `factor` le agrego un
    nuevo elemento que *no se encuentra en los niveles existentes*,
    ¿cuál sería el resultado esperado y por qué?
    
      - El nuevo elemento
      - `NA`

Esto tomaria como resultado el ‘NA’ ya que si el nuevo elemento que
estoy agregando no se encuentra dentro del mismo nivel, r no podria
reconocer el comando que estoy mandando por lo cual nos nos tirara un
valor, porque la agregación no la podria realizar. entonces el resultado
seria ‘NA’

9.  En SQL, ¿para qué utilizamos el keyword `HAVING`?

HAVING lo utilizamos al nosotros querer trabajar sobre un agregación (
Un GROUP BY) ya que en este caso WHERE no funciona. Entonces si queremos
hacer un WHERE dentro de una agregación debemos usar el keyword HAVING y
no WHERE.

10. Si quiero obtener como resultado las filas de la tabla A que no se
    encuentran en la tabla B, ¿cómo debería de completar la siguiente
    sentencia de SQL?
    
      - SELECT \* FROM A KEY B ON A.KEY = B.KEY WHERE A.KEY \<\> B.KEY

Extra: ¿Cuántos posibles exámenes de 5 preguntas se pueden realizar
utilizando como banco las diez acá presentadas? (responder con código de
R.)

## Sección II Preguntas prácticas.

  - Conteste las siguientes preguntas utilizando sus conocimientos de R.
    Adjunte el código que utilizó para llegar a sus conclusiones en un
    chunk del markdown.

A. De los clientes que están en más de un país,¿cuál cree que es el más
rentable y por qué?

B. Estrategia de negocio ha decidido que ya no operará en aquellos
territorios cuyas pérdidas sean “considerables”. Bajo su criterio,
¿cuáles son estos territorios y por qué ya no debemos operar ahí?

### II. Preguntas Prácticas

## A

``` r
library(dplyr)
```

    ## 
    ## Attaching package: 'dplyr'

    ## The following objects are masked from 'package:stats':
    ## 
    ##     filter, lag

    ## The following objects are masked from 'package:base':
    ## 
    ##     intersect, setdiff, setequal, union

``` r
library(tidyverse)
```

    ## ── Attaching packages ─────────────────────────────── tidyverse 1.3.0 ──

    ## ✓ ggplot2 3.3.2     ✓ purrr   0.3.4
    ## ✓ tibble  3.0.3     ✓ stringr 1.4.0
    ## ✓ tidyr   1.1.1     ✓ forcats 0.5.0
    ## ✓ readr   1.3.1

    ## ── Conflicts ────────────────────────────────── tidyverse_conflicts() ──
    ## x dplyr::filter() masks stats::filter()
    ## x dplyr::lag()    masks stats::lag()

``` r
library(highcharter)
```

    ## Registered S3 method overwritten by 'quantmod':
    ##   method            from
    ##   as.zoo.data.frame zoo

``` r
parcial_anonimo <- read_rds("parcial_anonimo.rds")
```

``` r
# Que clientes estan en más de un país 
parcial_anonimo %>% 
  select(Pais,Cliente,Venta) %>% 
  group_by(Cliente) %>% 
  filter(Pais > 1) %>% 
  summarise(clientesxpais = sum(Venta)) %>% 
  arrange(desc(clientesxpais)) %>% 
  filter(clientesxpais > 80000) %>% 
   hchart("column",hcaes(x = Cliente, y = clientesxpais)) %>% 
  hc_title(text = "<b>Mejores Clintes en más de un país<b>") 
```

    ## `summarise()` ungrouping output (override with `.groups` argument)

<!--html_preserve-->

<div id="htmlwidget-282e5a4e89f85a35c91d" class="highchart html-widget" style="width:100%;height:500px;">

</div>

<script type="application/json" data-for="htmlwidget-282e5a4e89f85a35c91d">{"x":{"hc_opts":{"chart":{"reflow":true},"title":{"text":"<b>Mejores Clintes en más de un país<b>"},"yAxis":{"title":{"text":"clientesxpais"},"type":"linear"},"credits":{"enabled":false},"exporting":{"enabled":false},"boost":{"enabled":false},"plotOptions":{"series":{"label":{"enabled":false},"turboThreshold":0,"showInLegend":false},"treemap":{"layoutAlgorithm":"squarified"},"scatter":{"marker":{"symbol":"circle"}}},"series":[{"group":"group","data":[{"Cliente":"af267306","clientesxpais":393666.42,"y":393666.42,"name":"af267306"},{"Cliente":"f6e6ba91","clientesxpais":185829.76,"y":185829.76,"name":"f6e6ba91"},{"Cliente":"93730e73","clientesxpais":135499.43,"y":135499.43,"name":"93730e73"},{"Cliente":"9314226b","clientesxpais":126636,"y":126636,"name":"9314226b"},{"Cliente":"f217abbd","clientesxpais":112182.86,"y":112182.86,"name":"f217abbd"},{"Cliente":"e1123460","clientesxpais":80362.46,"y":80362.46,"name":"e1123460"},{"Cliente":"dd0d7f4d","clientesxpais":80288.22,"y":80288.22,"name":"dd0d7f4d"}],"type":"column"}],"xAxis":{"type":"category","title":{"text":"Cliente"},"categories":null}},"theme":{"chart":{"backgroundColor":"transparent"},"colors":["#7cb5ec","#434348","#90ed7d","#f7a35c","#8085e9","#f15c80","#e4d354","#2b908f","#f45b5b","#91e8e1"]},"conf_opts":{"global":{"Date":null,"VMLRadialGradientURL":"http =//code.highcharts.com/list(version)/gfx/vml-radial-gradient.png","canvasToolsURL":"http =//code.highcharts.com/list(version)/modules/canvas-tools.js","getTimezoneOffset":null,"timezoneOffset":0,"useUTC":true},"lang":{"contextButtonTitle":"Chart context menu","decimalPoint":".","downloadJPEG":"Download JPEG image","downloadPDF":"Download PDF document","downloadPNG":"Download PNG image","downloadSVG":"Download SVG vector image","drillUpText":"Back to {series.name}","invalidDate":null,"loading":"Loading...","months":["January","February","March","April","May","June","July","August","September","October","November","December"],"noData":"No data to display","numericSymbols":["k","M","G","T","P","E"],"printChart":"Print chart","resetZoom":"Reset zoom","resetZoomTitle":"Reset zoom level 1:1","shortMonths":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"thousandsSep":" ","weekdays":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]}},"type":"chart","fonts":[],"debug":false},"evals":[],"jsHooks":[]}</script>

<!--/html_preserve-->

``` r
# Primero hice un Group By dentro de mis clientes, luego filtre que esos clientes estuiveran en más de 1 pais, para despues decirle que me sume todas las ventas que he realizado con ellos en sus distintos países. Despues le pedi que me lo ordenera en orde descendiente para reviasar los datos. 
# Para poder verlo graficamente filtre mi resultado en arriba de 80000 para visualizarlo mejor y despues realice la gráfica que se encuentra a continuación 
# En la gráfica me demiestras los clientes que más me facturas en más de un país. 
```

## B

``` r
parcial_anonimo %>% 
  select(Territorio,Venta) %>% 
  group_by(Territorio) %>%
  filter(Venta < -1) %>% 
  summarise(perdidas = n()) %>% 
  arrange(desc(perdidas)) %>% 
  filter(perdidas > 100) %>% 
  hchart("column",hcaes(x = Territorio, y = perdidas)) %>% 
  hc_title(text = "<b>Territorios con más perdidas<b>")
```

    ## `summarise()` ungrouping output (override with `.groups` argument)

<!--html_preserve-->

<div id="htmlwidget-f70e503481f5b99c2311" class="highchart html-widget" style="width:100%;height:500px;">

</div>

<script type="application/json" data-for="htmlwidget-f70e503481f5b99c2311">{"x":{"hc_opts":{"chart":{"reflow":true},"title":{"text":"<b>Territorios con más perdidas<b>"},"yAxis":{"title":{"text":"perdidas"},"type":"linear"},"credits":{"enabled":false},"exporting":{"enabled":false},"boost":{"enabled":false},"plotOptions":{"series":{"label":{"enabled":false},"turboThreshold":0,"showInLegend":false},"treemap":{"layoutAlgorithm":"squarified"},"scatter":{"marker":{"symbol":"circle"}}},"series":[{"group":"group","data":[{"Territorio":"f7dfc635","perdidas":537,"y":537,"name":"f7dfc635"},{"Territorio":"77192d63","perdidas":236,"y":236,"name":"77192d63"},{"Territorio":"2e812869","perdidas":149,"y":149,"name":"2e812869"},{"Territorio":"69c1b705","perdidas":133,"y":133,"name":"69c1b705"},{"Territorio":"bc8e06ed","perdidas":133,"y":133,"name":"bc8e06ed"},{"Territorio":"1d407777","perdidas":129,"y":129,"name":"1d407777"},{"Territorio":"67e9cc18","perdidas":105,"y":105,"name":"67e9cc18"}],"type":"column"}],"xAxis":{"type":"category","title":{"text":"Territorio"},"categories":null}},"theme":{"chart":{"backgroundColor":"transparent"},"colors":["#7cb5ec","#434348","#90ed7d","#f7a35c","#8085e9","#f15c80","#e4d354","#2b908f","#f45b5b","#91e8e1"]},"conf_opts":{"global":{"Date":null,"VMLRadialGradientURL":"http =//code.highcharts.com/list(version)/gfx/vml-radial-gradient.png","canvasToolsURL":"http =//code.highcharts.com/list(version)/modules/canvas-tools.js","getTimezoneOffset":null,"timezoneOffset":0,"useUTC":true},"lang":{"contextButtonTitle":"Chart context menu","decimalPoint":".","downloadJPEG":"Download JPEG image","downloadPDF":"Download PDF document","downloadPNG":"Download PNG image","downloadSVG":"Download SVG vector image","drillUpText":"Back to {series.name}","invalidDate":null,"loading":"Loading...","months":["January","February","March","April","May","June","July","August","September","October","November","December"],"noData":"No data to display","numericSymbols":["k","M","G","T","P","E"],"printChart":"Print chart","resetZoom":"Reset zoom","resetZoomTitle":"Reset zoom level 1:1","shortMonths":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"thousandsSep":" ","weekdays":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]}},"type":"chart","fonts":[],"debug":false},"evals":[],"jsHooks":[]}</script>

<!--/html_preserve-->

``` r
# Primero lo que hice fue agrupar por territorio, despues a ese territorio le puse un filtro que sus ventas fuerna < -1 para quedarme solo con las perdidas. Despues hice un conteo de perdidas por territorio. Lo ordene de manera descendiente luego por suposición puse un número de 100 perdidas en conteo como límite para graficar 
# En los países que se presentan en la gráfica deberiamos de considerar salir de operaciones porque tienen más de 100 operaciones por perdida, el más alto siendo de 537, por lo que considero importante remplantearse las actividades en esto países. 
```
